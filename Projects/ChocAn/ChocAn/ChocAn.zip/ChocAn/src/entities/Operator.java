package entities;

public class Operator {
	private int operatorNum; // 9-digit Operator Number for verifying identity
	private String operatorName; // 20-character (or less) Operator Name

	public Operator() {
		operatorNum = 123456789;
		operatorName = "TESTNAME";
	}
}
